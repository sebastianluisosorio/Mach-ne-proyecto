from pathlib import Path
import json, warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_validate
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor, RandomForestClassifier
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, roc_auc_score, average_precision_score, confusion_matrix
from sklearn.inspection import permutation_importance
warnings.filterwarnings('ignore')
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'resultados'; OUT.mkdir(exist_ok=True)
D=pd.read_csv(ROOT/'datos/base_refrescos_nevera.csv'); assert D.id_tienda.is_unique
SEED=42; np.random.seed(SEED)
# Solo atributos del entorno/operacion observables antes de asignar la nevera.
# Se excluyen resultados de ventas, unidades, mix, participaciones, proveedor principal y atributos de nevera FEMSA.
exclude={'id_tienda','latitud','longitud','nevera_femsa','cambio_proveedor_principal_6m','proveedor_principal','presencia_neveras','num_neveras_femsa','puertas_nevera_femsa','antiguedad_nevera_femsa_anios','nevera_femsa_operativa','ventas_femsa_cop_mes','ventas_postobon_cop_mes','ventas_bebidas_cop_mes','ventas_otras_categorias_cop_mes','ventas_totales_tienda_cop_mes','ventas_por_m2_cop','peso_bebidas_en_ventas','share_femsa_valor','ticket_promedio_cop','unidades_femsa_mes','unidades_postobon_mes','n_skus_activos_femsa','n_skus_activos_postobon'}
features=[c for c in D if c not in exclude and not c.startswith(('u_','cop_'))]
# Quitar variables comerciales posiblemente posteriores a la asignacion para el efecto causal.
post={'visitas_mes_femsa','visitas_mes_postobon','pct_quiebre_femsa','pct_quiebre_postobon','credito_femsa','credito_postobon','material_pop_femsa','material_pop_postobon','promos_activas_femsa','promos_activas_postobon','indice_precio_femsa','indice_precio_postobon','n_referencias_total'}
features=[c for c in features if c not in post]
cat=[c for c in features if D[c].dtype=='object']; num=[c for c in features if c not in cat]
prep=ColumnTransformer([('num',Pipeline([('imputer',SimpleImputer(strategy='median')),('scale',StandardScaler())]),num),('cat',Pipeline([('imputer',SimpleImputer(strategy='most_frequent')),('ohe',OneHotEncoder(handle_unknown='ignore',sparse_output=False))]),cat)],sparse_threshold=0)
X=D[features]; y=D.ventas_femsa_cop_mes; treatment=D.nevera_femsa
train,test=train_test_split(np.arange(len(D)),test_size=.2,random_state=SEED,stratify=treatment)
models={'Lineal Ridge':Ridge(alpha=100),'Random Forest':RandomForestRegressor(n_estimators=70,min_samples_leaf=8,max_features=.75,n_jobs=-1,random_state=SEED),'Gradient Boosting':HistGradientBoostingRegressor(max_iter=130,max_leaf_nodes=20,l2_regularization=15,random_state=SEED)}
metrics=[]
for name,model in models.items():
 p=Pipeline([('prep',prep),('model',model)])
 cv=cross_validate(p,X.iloc[train],y.iloc[train],cv=3,scoring={'mae':'neg_mean_absolute_error','r2':'r2'},n_jobs=1)
 p.fit(X.iloc[train],y.iloc[train]); yp=p.predict(X.iloc[test]);metrics.append({'modelo':name,'cv_mae':round(-cv['test_mae'].mean()),'cv_r2':round(cv['test_r2'].mean(),4),'test_mae':round(mean_absolute_error(y.iloc[test],yp)),'test_r2':round(r2_score(y.iloc[test],yp),4)})
pd.DataFrame(metrics).to_csv(OUT/'comparacion_ventas.csv',index=False)
# T-learner con predictores entrenados por separado. Prediccion contrafactual para todas las tiendas.
# Propensity trimming para diagnosticar soporte comun; no se proclama causalidad identificada.
from sklearn.linear_model import LogisticRegression
prop=Pipeline([('prep',prep),('model',LogisticRegression(max_iter=400,C=.1))]);prop.fit(X.iloc[train],treatment.iloc[train]);ps=prop.predict_proba(X)[:,1]
base=HistGradientBoostingRegressor(max_iter=170,max_leaf_nodes=18,min_samples_leaf=35,l2_regularization=20,random_state=SEED)
m0=Pipeline([('prep',prep),('model',base)]);m1=Pipeline([('prep',prep),('model',HistGradientBoostingRegressor(max_iter=170,max_leaf_nodes=18,min_samples_leaf=35,l2_regularization=20,random_state=SEED))])
m0.fit(X.loc[treatment==0],y.loc[treatment==0]);m1.fit(X.loc[treatment==1],y.loc[treatment==1]); uplift=m1.predict(X)-m0.predict(X)
# Riesgo: usar solo caracteristicas pre-decision; el cambio 6m es la etiqueta, no feature.
risk_y=D.cambio_proveedor_principal_6m
rt,rv=train_test_split(np.arange(len(D)),test_size=.25,random_state=SEED,stratify=risk_y)
risks={'Regresion logistica':LogisticRegression(max_iter=500,C=.3),'Bosque con ponderacion':RandomForestClassifier(n_estimators=90,min_samples_leaf=12,class_weight='balanced_subsample',n_jobs=-1,random_state=SEED)}
riskrows=[]; fitted={}
for name,model in risks.items():
 p=Pipeline([('prep',prep),('model',model)]);p.fit(X.iloc[rt],risk_y.iloc[rt]); pr=p.predict_proba(X.iloc[rv])[:,1]
 riskrows.append({'modelo':name,'roc_auc':round(roc_auc_score(risk_y.iloc[rv],pr),4),'average_precision':round(average_precision_score(risk_y.iloc[rv],pr),4)});fitted[name]=p
pd.DataFrame(riskrows).to_csv(OUT/'comparacion_riesgo.csv',index=False)
best=max(riskrows,key=lambda z:z['average_precision'])['modelo'];rp=fitted[best].predict_proba(X)[:,1]
# Retener cuando p*0.40*500000 > 50000 => p > 0.25
threshold=50000/(.4*500000)
elig=(D.nevera_femsa==0)&~((D.nevera_postobon==1)&(D.area_m2<12))
res=D[['id_tienda','region','ciudad','tipo_negocio','latitud','longitud','clientes_prom_dia','ventas_femsa_cop_mes','nevera_femsa','nevera_postobon','area_m2']].copy()
res['elegible']=elig;res['propension_nevera']=ps;res['ventas_adicionales_estimadas']=uplift;res['ganancia_estimada_cop_mes']=.25*uplift-60000;res['probabilidad_cambio']=rp;res['riesgo_cambio']=np.where(rp>=threshold,'Alto','Bajo')
# Evitar extrapolacion extrema: restringir a soporte comun de propension 0.05-0.95 si hay suficientes.
support=(ps>=.05)&(ps<=.95); pool=res[elig&support] if (elig&support).sum()>=1000 else res[elig]
chosen=pool.nlargest(1000,'ganancia_estimada_cop_mes').copy(); assert len(chosen)==1000 and chosen.id_tienda.is_unique and chosen.elegible.all()
chosen[['id_tienda','ganancia_estimada_cop_mes','riesgo_cambio']].round({'ganancia_estimada_cop_mes':0}).to_csv(ROOT/'lista_grupoX.csv',index=False)
res['seleccionada']=res.id_tienda.isin(chosen.id_tienda)
res.to_csv(OUT/'tiendas_tablero.csv',index=False)
by_sales=res[elig].nlargest(1000,'ventas_femsa_cop_mes');by_traffic=res[elig].nlargest(1000,'clientes_prom_dia')
summary={'n_tiendas':len(D),'n_elegibles':int(elig.sum()),'con_nevera':int(treatment.sum()),'sin_nevera':int((treatment==0).sum()),'n_soporte_comun':int((elig&support).sum()),'ganancia_total_estimacion':round(chosen.ganancia_estimada_cop_mes.sum()),'ganancia_regla_ventas':round(by_sales.ganancia_estimada_cop_mes.sum()),'ganancia_regla_trafico':round(by_traffic.ganancia_estimada_cop_mes.sum()),'ganancia_media':round(chosen.ganancia_estimada_cop_mes.mean()),'riesgo_alto_seleccionadas':int((chosen.riesgo_cambio=='Alto').sum()),'diferencia_promedios_simple':round(y[treatment==1].mean()-y[treatment==0].mean()),'uplift_promedio_elegibles':round(res.loc[elig,'ventas_adicionales_estimadas'].mean()),'riesgo_prevalencia':round(risk_y.mean(),4),'riesgo_modelo':best,'umbral_riesgo':threshold,'features':features,'metricas_ventas':metrics,'metricas_riesgo':riskrows}
(OUT/'resumen.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
# Importancia por permutacion sobre datos reservados del modelo de ventas
p=Pipeline([('prep',prep),('model',HistGradientBoostingRegressor(max_iter=130,max_leaf_nodes=20,l2_regularization=15,random_state=SEED))]);p.fit(X.iloc[train],y.iloc[train]);imp=permutation_importance(p,X.iloc[test[:1500]],y.iloc[test[:1500]],n_repeats=2,random_state=SEED,scoring='neg_mean_absolute_error');pd.DataFrame({'variable':features,'importancia':imp.importances_mean}).sort_values('importancia',ascending=False).to_csv(OUT/'importancia_variables.csv',index=False)
print(json.dumps({k:v for k,v in summary.items() if k not in ('features','metricas_ventas','metricas_riesgo')},ensure_ascii=False,indent=2))
