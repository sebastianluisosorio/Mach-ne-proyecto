import json
from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st
P=Path(__file__).resolve().parent
st.set_page_config(page_title='FEMSA | Decisión de neveras',layout='wide')
st.title('FEMSA · Ubicación de 1.000 neveras')
st.caption('Datos simulados. Ganancias y riesgos son estimaciones, no resultados causales verificados.')
d=pd.read_csv(P/'resultados/tiendas_tablero.csv');s=json.loads((P/'resultados/resumen.json').read_text(encoding='utf-8'))
a,b,c=st.columns(3)
with a: region=st.multiselect('Región',sorted(d.region.unique()))
with b: ciudad=st.multiselect('Ciudad',sorted(d[d.region.isin(region)].ciudad.unique()) if region else sorted(d.ciudad.unique()))
with c: tipo=st.multiselect('Tipo de negocio',sorted(d.tipo_negocio.unique()))
f=d.copy()
if region:f=f[f.region.isin(region)]
if ciudad:f=f[f.ciudad.isin(ciudad)]
if tipo:f=f[f.tipo_negocio.isin(tipo)]
sel=f[f.seleccionada]
a,b,c=st.columns(3);a.metric('Neveras en filtro',len(sel));b.metric('Ganancia estimada mensual',f'${sel.ganancia_estimada_cop_mes.sum():,.0f}');c.metric('Riesgo alto',int((sel.riesgo_cambio=='Alto').sum()))
st.subheader('Mapa de tiendas seleccionadas')
if len(sel):st.plotly_chart(px.scatter_mapbox(sel,lat='latitud',lon='longitud',hover_name='id_tienda',hover_data=['ciudad','ganancia_estimada_cop_mes','riesgo_cambio'],zoom=4,height=470).update_layout(mapbox_style='open-street-map',margin=dict(l=0,r=0,t=0,b=0)),use_container_width=True)
st.subheader('Comparación de estrategias')
comp=pd.DataFrame({'Estrategia':['Modelo de efecto','Mayores ventas','Mayor tráfico'],'COP por mes':[s['ganancia_total_estimacion'],s['ganancia_regla_ventas'],s['ganancia_regla_trafico']]})
st.plotly_chart(px.bar(comp,x='Estrategia',y='COP por mes',text_auto='.3s'),use_container_width=True)
st.subheader('Riesgo de cambio de proveedor')
st.plotly_chart(px.histogram(sel,x='riesgo_cambio',color='riesgo_cambio'),use_container_width=True)
st.caption(f"Umbral de acción de retención: {s['umbral_riesgo']:.0%}. Beneficio esperado = probabilidad × 40% × $500.000 − $50.000. Las probabilidades requieren validación de calibración.")
st.subheader('Variables importantes para predecir ventas')
imp=pd.read_csv(P/'resultados/importancia_variables.csv').head(12)
st.plotly_chart(px.bar(imp.sort_values('importancia'),x='importancia',y='variable',orientation='h'),use_container_width=True)
st.subheader('Consultar tienda')
ident=st.text_input('ID de tienda (por ejemplo, T00001)').strip().upper()
if ident:
 match=d[d.id_tienda==ident]
 if len(match):st.dataframe(match.T,use_container_width=True)
 else:st.warning('No se encontró ese ID')
st.subheader('Lista filtrada')
st.dataframe(sel[['id_tienda','region','ciudad','tipo_negocio','ganancia_estimada_cop_mes','riesgo_cambio']],use_container_width=True)
st.download_button('Descargar selección filtrada',sel[['id_tienda','ganancia_estimada_cop_mes','riesgo_cambio']].to_csv(index=False),file_name='seleccion_filtrada.csv')
