# Proyecto FEMSA · Machine Learning (datos simulados)

## Ejecución

1. Instalar Python 3.10+.
2. En la carpeta del proyecto: `pip install -r requirements.txt`
3. Ejecutar desde los datos originales: `python analisis.py`
4. Abrir el tablero: `streamlit run app.py`

Semilla fija: 42. La lista final es `lista_grupoX.csv` (renombrar X según el grupo). El código produce los CSV de métricas, importancia y tabla del tablero en `resultados/`.

## Metodología

* 38.000 tiendas, 109 columnas. División 80/20 estratificada por nevera para regresión; CV de 3 pliegues en entrenamiento. Tres algoritmos: Ridge, Random Forest, HistGradientBoosting.
* Excluimos del modelo predictivo unidades y ventas de productos, agregados, participaciones y variables derivadas de la nevera FEMSA, por fuga de información. También excluimos visitas, promociones y otras variables comerciales potencialmente posteriores al tratamiento para estimar el efecto.
* Efecto: T-learner con dos regresores de boosting, uno para nevera=0 y otro para nevera=1. Diferencia de predicciones = ventas adicionales estimadas. Propensión estimada para diagnóstico de soporte común; se priorizan tiendas con 0.05<=p<=0.95 si existen al menos 1000. No demuestra causalidad: pueden existir confundidores no observados.
* Riesgo: logística sin ponderación y bosque ponderado; métricas ROC-AUC y precisión promedio en holdout estratificado. Prevalencia cercana a 9.5%; la precisión promedio se usa para comparar en desbalance. Umbral económico 50.000/(0.4×500.000)=0.25. Se debe evaluar calibración de probabilidades antes de aplicar la política de retención.
* Elegibilidad: sin nevera FEMSA y no (nevera Postobón y área <12m²). Se eligen exactamente 1000 por 0.25×uplift−60000. Baselines: top 1000 por ventas FEMSA actuales y por clientes diarios, evaluados con el mismo uplift estimado.

## Limitaciones importantes

El tratamiento no fue aleatorio; el T-learner supone ausencia de confusión no medida y soporte común. El dataset cubre un solo mes. La ganancia real es desconocida; las cifras son estimaciones, no validación causal. La CV del modelo de ventas no valida el uplift. Las etiquetas de riesgo pueden depender de variables no observadas; la probabilidad de riesgo debe calibrarse para tomar decisiones de retención.


